---
title: GenerZy
emoji: ⚡
colorFrom: yellow
colorTo: green
sdk: docker
pinned: false
license: mit
---

# GenerZy - Keep Your Bar Alive

**"Every video game has an energy bar - why shouldn't your life have one?"**

GenerZy turns your daily movement into a live energy bar. No overwhelming numbers, no guilt - just one honest visual that fills when you move and drains when you sit.

Built for the MotionSense AI Competition - 1st Place.

## What it does

- Classifies your activity as SEDENTARY, STANDING, or ACTIVE using smartphone sensor data
- Translates that into a live energy bar you actually want to watch
- Powered by a Gradient Boosting model with 99.5% validation accuracy

## Model

- **Algorithm:** Gradient Boosting Classifier
- **Validation Accuracy:** 99.46%
- **Test Accuracy:** 96.47%
- **Features:** 245 sensor signals (accelerometer + gyroscope)
- **Classes:** SEDENTARY / STANDING / ACTIVE

## Built by

Maryam Shanabli & Lujain Osaily

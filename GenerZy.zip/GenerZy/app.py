import streamlit as st
import numpy as np
import joblib
import json
import os

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="GenerZy - Keep Your Bar Alive",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Load assets ──────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__))

@st.cache_resource
def load_model():
    model  = joblib.load(os.path.join(BASE, "model", "best_gradient_boosting_model.joblib"))
    scaler = joblib.load(os.path.join(BASE, "model", "robust_scaler_final.joblib"))
    return model, scaler

@st.cache_data
def load_presets():
    with open(os.path.join(BASE, "data", "presets.json")) as f:
        return json.load(f)

model, scaler = load_model()
presets_data  = load_presets()

# ── CSS - full design system ──────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Raleway:wght@400;600;700;900&family=DM+Sans:wght@300;400;500&display=swap');

/* ── Reset & base ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body, [data-testid="stAppViewContainer"], [data-testid="stMain"] {
    background: #EDE8E0 !important;
    font-family: 'DM Sans', sans-serif;
    color: #3A3530;
}

[data-testid="stHeader"],
[data-testid="stToolbar"],
[data-testid="stSidebar"],
footer { display: none !important; }

/* ── Hide default streamlit padding ── */
.block-container {
    padding: 0 !important;
    max-width: 100% !important;
}

/* ── Typography ── */
.gz-display {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    line-height: 1.05;
    color: #3A3530;
}
.gz-label {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    font-size: 0.75rem;
    color: #8A7E72;
}
.gz-body {
    font-family: 'DM Sans', sans-serif;
    font-weight: 400;
    color: #5C5048;
    line-height: 1.7;
}

/* ── HERO section ── */
.hero-section {
    min-height: 100vh;
    background: #EDE8E0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 4rem 2rem;
    position: relative;
    overflow: hidden;
}

.hero-blob-tl {
    position: absolute; top: -80px; left: -80px;
    width: 320px; height: 320px;
    background: #C8B99A; opacity: 0.45; border-radius: 61% 39% 54% 46% / 45% 55% 45% 55%;
    pointer-events: none;
}
.hero-blob-br {
    position: absolute; bottom: -100px; right: -60px;
    width: 280px; height: 280px;
    background: #C8B99A; opacity: 0.3; border-radius: 45% 55% 39% 61% / 55% 45% 55% 45%;
    pointer-events: none;
}

.hero-icon {
    font-size: 3rem;
    margin-bottom: 1.5rem;
    animation: float 4s ease-in-out infinite;
}
@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50%       { transform: translateY(-10px); }
}

.hero-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: clamp(3rem, 7vw, 6rem);
    color: #3A3530;
    letter-spacing: -0.02em;
    margin-bottom: 0.5rem;
}
.hero-subtitle {
    font-family: 'Raleway', sans-serif;
    font-weight: 600;
    font-size: clamp(1rem, 2.2vw, 1.5rem);
    color: #8A7E72;
    font-style: italic;
    margin-bottom: 2rem;
}
.hero-quote {
    background: #FAF8F4;
    border-radius: 20px;
    padding: 1.5rem 2.5rem;
    max-width: 600px;
    margin: 0 auto 2.5rem;
    box-shadow: 0 4px 24px rgba(58,53,48,0.07);
}
.hero-quote p {
    font-family: 'DM Sans', sans-serif;
    font-size: 1.15rem;
    color: #5C5048;
    line-height: 1.7;
}
.hero-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    background: #3A3530;
    color: #EDE8E0;
    padding: 0.5rem 1.25rem;
    border-radius: 100px;
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 0.85rem;
    letter-spacing: 0.05em;
    margin-bottom: 1rem;
}
.hero-scroll-hint {
    position: absolute; bottom: 2rem;
    font-family: 'DM Sans', sans-serif;
    font-size: 0.85rem; color: #8A7E72;
    animation: bounce 2s ease-in-out infinite;
}
@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(6px); }
}

/* ── Section wrapper ── */
.gz-section {
    padding: 5rem 2rem;
    max-width: 960px;
    margin: 0 auto;
}
.gz-section-wide {
    padding: 5rem 2rem;
    max-width: 1100px;
    margin: 0 auto;
}
.gz-section-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: clamp(1.8rem, 4vw, 3rem);
    color: #3A3530;
    text-align: center;
    margin-bottom: 0.75rem;
}
.gz-section-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 1.05rem;
    color: #8A7E72;
    text-align: center;
    margin-bottom: 3rem;
}
.gz-divider {
    width: 60px; height: 4px;
    background: #C8B99A;
    border-radius: 2px;
    margin: 0.75rem auto 3rem;
}

/* ── Energy bar ── */
.energy-card {
    background: #FAF8F4;
    border-radius: 28px;
    padding: 3rem 3rem 2.5rem;
    box-shadow: 0 8px 40px rgba(58,53,48,0.09);
    text-align: center;
    position: relative;
    overflow: hidden;
}
.energy-label-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}
.energy-bar-track {
    width: 100%;
    height: 52px;
    background: #E8E2D8;
    border-radius: 100px;
    overflow: hidden;
    position: relative;
}
.energy-bar-fill {
    height: 100%;
    border-radius: 100px;
    transition: width 1.2s cubic-bezier(0.4, 0, 0.2, 1),
                background 0.8s ease;
    position: relative;
    overflow: hidden;
}
.energy-bar-fill::after {
    content: '';
    position: absolute;
    top: 0; left: -100%; width: 60%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    animation: shimmer 2.5s ease-in-out infinite;
}
@keyframes shimmer {
    0%   { left: -100%; }
    100% { left: 200%; }
}
.energy-pct {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: 3.5rem;
    line-height: 1;
    margin: 1.25rem 0 0.25rem;
}
.energy-class-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.6rem;
    padding: 0.5rem 1.5rem;
    border-radius: 100px;
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 1rem;
    letter-spacing: 0.08em;
    margin: 0.5rem 0 1rem;
}
.energy-nudge {
    font-family: 'DM Sans', sans-serif;
    font-size: 1.1rem;
    color: #5C5048;
    font-style: italic;
    padding: 0.75rem 1.5rem;
    background: #EDE8E0;
    border-radius: 12px;
    margin-top: 0.5rem;
}

/* bar color states */
.bar-active    { background: linear-gradient(90deg, #5BBF5B, #7EC67E); }
.bar-standing  { background: linear-gradient(90deg, #D4A033, #E8B84B); }
.bar-sedentary { background: linear-gradient(90deg, #C85040, #E07060); }

.badge-active    { background: #D6F0D6; color: #2A7A2A; }
.badge-standing  { background: #FDF0D0; color: #7A5A10; }
.badge-sedentary { background: #FAD8D4; color: #8A2010; }

.pct-active    { color: #2A7A2A; }
.pct-standing  { color: #7A5A10; }
.pct-sedentary { color: #C85040; }

/* ── Preset cards ── */
.preset-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.25rem;
    margin-bottom: 2rem;
}
.preset-card {
    background: #FAF8F4;
    border: 2.5px solid transparent;
    border-radius: 20px;
    padding: 1.75rem 1.25rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.25s ease;
    box-shadow: 0 2px 12px rgba(58,53,48,0.06);
}
.preset-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 28px rgba(58,53,48,0.12);
    border-color: #C8B99A;
}
.preset-card.selected {
    border-color: #3A3530;
    background: #3A3530;
    color: #EDE8E0;
}
.preset-card.selected .preset-card-title { color: #EDE8E0; }
.preset-card.selected .preset-card-sub   { color: #C8B99A; }
.preset-emoji { font-size: 2.5rem; margin-bottom: 0.75rem; display: block; }
.preset-card-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 0.95rem;
    color: #3A3530;
    margin-bottom: 0.25rem;
}
.preset-card-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.8rem;
    color: #8A7E72;
}

/* ── Proba bars ── */
.proba-row {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.6rem;
}
.proba-name {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 0.78rem;
    letter-spacing: 0.08em;
    width: 90px;
    flex-shrink: 0;
    color: #5C5048;
}
.proba-track {
    flex: 1;
    height: 10px;
    background: #E8E2D8;
    border-radius: 100px;
    overflow: hidden;
}
.proba-fill {
    height: 100%;
    border-radius: 100px;
    transition: width 1s ease;
}
.proba-pct {
    font-family: 'DM Sans', sans-serif;
    font-weight: 500;
    font-size: 0.82rem;
    color: #8A7E72;
    width: 40px;
    text-align: right;
}

/* ── Timeline ── */
.timeline-card {
    background: #3A3530;
    border-radius: 28px;
    padding: 3rem;
    color: #EDE8E0;
}
.timeline-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
    color: #EDE8E0;
}
.timeline-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.95rem;
    color: #C8B99A;
    margin-bottom: 2rem;
}
.timeline-row {
    display: flex;
    align-items: flex-end;
    gap: 0.5rem;
    margin-bottom: 0.75rem;
}
.tl-slot {
    flex: 1;
    text-align: center;
}
.tl-bar-outer {
    height: 80px;
    display: flex;
    align-items: flex-end;
    justify-content: center;
}
.tl-bar {
    width: 100%;
    max-width: 40px;
    border-radius: 8px 8px 0 0;
    transition: height 0.5s ease;
}
.tl-time {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.72rem;
    color: #8A7E72;
    margin-top: 0.35rem;
}
.tl-emoji {
    font-size: 1rem;
    display: block;
    margin-bottom: 0.25rem;
}
.timeline-insight {
    background: rgba(255,255,255,0.07);
    border-radius: 12px;
    padding: 1rem 1.5rem;
    margin-top: 1.5rem;
    font-family: 'DM Sans', sans-serif;
    font-size: 0.95rem;
    color: #C8B99A;
    font-style: italic;
    text-align: center;
}

/* ── How it works ── */
.how-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1.5rem;
}
.how-card {
    background: #FAF8F4;
    border-radius: 20px;
    padding: 2rem 1.5rem;
    text-align: center;
    box-shadow: 0 2px 16px rgba(58,53,48,0.06);
}
.how-icon {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    display: block;
}
.how-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 1rem;
    color: #3A3530;
    margin-bottom: 0.5rem;
}
.how-desc {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.9rem;
    color: #8A7E72;
    line-height: 1.6;
}
.how-arrow {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: #C8B99A;
    padding-top: 2rem;
}

/* ── Hood / stats ── */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}
.stat-chip {
    background: #FAF8F4;
    border-radius: 14px;
    padding: 1.25rem 1.5rem;
    box-shadow: 0 2px 10px rgba(58,53,48,0.05);
}
.stat-chip-label {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 0.7rem;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #8A7E72;
    margin-bottom: 0.25rem;
}
.stat-chip-value {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: 1.5rem;
    color: #3A3530;
}
.trophy-banner {
    background: linear-gradient(135deg, #3A3530, #5C5048);
    border-radius: 20px;
    padding: 1.5rem 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-top: 1.5rem;
}
.trophy-text {
    font-family: 'Raleway', sans-serif;
    font-weight: 700;
    font-size: 1rem;
    color: #EDE8E0;
}
.trophy-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.85rem;
    color: #C8B99A;
}

/* ── Footer ── */
.gz-footer {
    background: #3A3530;
    padding: 3rem 2rem;
    text-align: center;
}
.gz-footer-title {
    font-family: 'Raleway', sans-serif;
    font-weight: 900;
    font-size: 2rem;
    color: #EDE8E0;
    margin-bottom: 0.5rem;
}
.gz-footer-tagline {
    font-family: 'DM Sans', sans-serif;
    font-style: italic;
    color: #C8B99A;
    font-size: 1rem;
    margin-bottom: 1.5rem;
}
.gz-footer-names {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.9rem;
    color: #8A7E72;
}

/* ── Expander override ── */
[data-testid="stExpander"] {
    background: #FAF8F4 !important;
    border: none !important;
    border-radius: 20px !important;
    box-shadow: 0 2px 16px rgba(58,53,48,0.06) !important;
    overflow: hidden;
}
[data-testid="stExpander"] summary {
    font-family: 'Raleway', sans-serif !important;
    font-weight: 700 !important;
    color: #3A3530 !important;
    padding: 1.25rem 1.5rem !important;
}
</style>
""", unsafe_allow_html=True)

# ── State ────────────────────────────────────────────────────────────────────
if "selected_preset" not in st.session_state:
    st.session_state.selected_preset = None
if "prediction" not in st.session_state:
    st.session_state.prediction = None
if "proba" not in st.session_state:
    st.session_state.proba = None

# ── Helpers ──────────────────────────────────────────────────────────────────
CLASS_CONFIG = {
    "SEDENTARY": {
        "pct": 18, "bar_class": "bar-sedentary", "badge_class": "badge-sedentary",
        "pct_class": "pct-sedentary", "proba_color": "#E07060",
        "nudge": "⚠️ Your bar is draining... time to get up and move.",
    },
    "STANDING": {
        "pct": 58, "bar_class": "bar-standing", "badge_class": "badge-standing",
        "pct_class": "pct-standing", "proba_color": "#E8B84B",
        "nudge": "🙂 You're holding steady. A short walk would charge you up.",
    },
    "ACTIVE": {
        "pct": 92, "bar_class": "bar-active", "badge_class": "badge-active",
        "pct_class": "pct-active", "proba_color": "#7EC67E",
        "nudge": "⚡ Bar is charging! Every step counts - keep going!",
    },
}
EMOJI = {"SEDENTARY": "🪑", "STANDING": "🧍", "ACTIVE": "🏃"}

def run_prediction(preset_key):
    vec = np.array(presets_data["presets"][preset_key]["features"]).reshape(1, -1)
    scaled = scaler.transform(vec)
    pred_id  = model.predict(scaled)[0]
    proba    = model.predict_proba(scaled)[0]
    label_map = {0: "SEDENTARY", 1: "STANDING", 2: "ACTIVE"}
    return label_map[pred_id], proba

# ── ① HERO ───────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero-section">
    <div class="hero-blob-tl"></div>
    <div class="hero-blob-br"></div>
    <div class="hero-icon">⚡</div>
    <div class="hero-title">GenerZy</div>
    <div class="hero-subtitle">Small steps. Big energy. Keep your bar alive.</div>
    <div class="hero-quote">
        <p>"Every video game has an energy bar -<br>why shouldn't your life have one?"</p>
    </div>
    <div class="hero-badge">🏆 &nbsp;1st Place · MotionSense AI Competition</div>
    <div class="hero-scroll-hint">↓ &nbsp;Try it below</div>
</div>
""", unsafe_allow_html=True)

# ── ② ENERGY BAR + PRESETS ───────────────────────────────────────────────────
st.markdown("""
<div class="gz-section">
    <div class="gz-section-title">Your Energy Bar</div>
    <p class="gz-section-sub">Choose a moment from your day. Watch the bar react.</p>
    <div class="gz-divider"></div>
</div>
""", unsafe_allow_html=True)

with st.container():
    col_left, col_right = st.columns([1, 1], gap="large")

    # - Preset picker -
    with col_left:
        st.markdown("<div style='padding: 0 0.5rem;'>", unsafe_allow_html=True)
        st.markdown("<p class='gz-label' style='margin-bottom:1rem;'>Pick your moment</p>", unsafe_allow_html=True)

        presets = presets_data["presets"]
        preset_keys   = ["desk", "waiting", "run"]
        preset_emojis = ["🪑", "🧍", "🏃"]
        preset_titles = [
            "Sat at your desk\nfor 3 hours",
            "Waiting in line\nat a café",
            "Morning\nrun",
        ]

        for i, (key, emoji, title) in enumerate(zip(preset_keys, preset_emojis, preset_titles)):
            selected_class = "selected" if st.session_state.selected_preset == key else ""
            if st.button(
                f"{emoji}  {title.replace(chr(10), ' · ')}",
                key=f"preset_{key}",
                use_container_width=True,
            ):
                st.session_state.selected_preset = key
                pred_label, pred_proba = run_prediction(key)
                st.session_state.prediction = pred_label
                st.session_state.proba      = pred_proba
                st.rerun()

        st.markdown("</div>", unsafe_allow_html=True)

    # - Energy bar -
    with col_right:
        pred  = st.session_state.prediction
        proba = st.session_state.proba

        if pred is None:
            # Default / idle state
            bar_pct       = 0
            bar_class     = "bar-sedentary"
            badge_class   = "badge-sedentary"
            pct_class     = "pct-sedentary"
            nudge         = "← Pick a moment to see your bar"
            badge_label   = "WAITING..."
            badge_emoji   = "💤"
            bar_pct_show  = "-"
        else:
            cfg           = CLASS_CONFIG[pred]
            bar_pct       = cfg["pct"]
            bar_class     = cfg["bar_class"]
            badge_class   = cfg["badge_class"]
            pct_class     = cfg["pct_class"]
            nudge         = cfg["nudge"]
            badge_label   = pred
            badge_emoji   = EMOJI[pred]
            bar_pct_show  = f"{bar_pct}%"

        st.markdown(f"""
        <div class="energy-card">
            <div class="energy-bar-track">
                <div class="energy-bar-fill {bar_class}" style="width:{bar_pct}%;"></div>
            </div>
            <div class="{pct_class} energy-pct">{bar_pct_show}</div>
            <span class="energy-class-badge {badge_class}">{badge_emoji} &nbsp;{badge_label}</span>
            <div class="energy-nudge">{nudge}</div>
        </div>
        """, unsafe_allow_html=True)

        if proba is not None:
            st.markdown("<p class='gz-label' style='margin-top:1.5rem;margin-bottom:0.75rem;'>AI Confidence</p>",
                        unsafe_allow_html=True)
            class_names   = ["SEDENTARY", "STANDING", "ACTIVE"]
            proba_colors  = ["#E07060", "#E8B84B", "#7EC67E"]
            for name, p, color in zip(class_names, proba, proba_colors):
                pct_int = int(round(p * 100))
                st.markdown(f"""
                <div class="proba-row">
                    <span class="proba-name">{name}</span>
                    <div class="proba-track">
                        <div class="proba-fill" style="width:{pct_int}%;background:{color};"></div>
                    </div>
                    <span class="proba-pct">{pct_int}%</span>
                </div>
                """, unsafe_allow_html=True)

# ── ③ DAY TIMELINE ───────────────────────────────────────────────────────────
st.markdown("<div style='height:2rem;'></div>", unsafe_allow_html=True)
st.markdown("""
<div class="gz-section-wide">
""", unsafe_allow_html=True)

timeline = [
    {"time": "7am",  "emoji": "🏃", "pct": 88,  "color": "#7EC67E"},
    {"time": "9am",  "emoji": "🪑", "pct": 68,  "color": "#E07060"},
    {"time": "11am", "emoji": "🪑", "pct": 45,  "color": "#E07060"},
    {"time": "1pm",  "emoji": "🧍", "pct": 55,  "color": "#E8B84B"},
    {"time": "3pm",  "emoji": "🪑", "pct": 22,  "color": "#E07060"},
    {"time": "5pm",  "emoji": "🏃", "pct": 75,  "color": "#7EC67E"},
    {"time": "7pm",  "emoji": "🪑", "pct": 50,  "color": "#E07060"},
    {"time": "9pm",  "emoji": "🧍", "pct": 60,  "color": "#E8B84B"},
]

slots_html = ""
for slot in timeline:
    bar_h = int(slot["pct"] * 0.8)
    slots_html += f"""
    <div class="tl-slot">
        <span class="tl-emoji">{slot['emoji']}</span>
        <div class="tl-bar-outer">
            <div class="tl-bar" style="height:{bar_h}px;background:{slot['color']};"></div>
        </div>
        <div class="tl-time">{slot['time']}</div>
    </div>
    """

st.markdown(f"""
<div class="timeline-card">
    <div class="timeline-title">A Typical Day's Energy Bar</div>
    <div class="timeline-sub">This is what GenerZy sees. Most people's bar hits zero by 3pm.</div>
    <div class="timeline-row">{slots_html}</div>
    <div class="timeline-insight">
        "GenerZy tells you before it's too late - not with numbers, but with your bar."
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)

# ── ④ HOW IT WORKS ───────────────────────────────────────────────────────────
st.markdown("""
<div class="gz-section">
    <div class="gz-section-title">How It Works</div>
    <p class="gz-section-sub">The science behind the bar - kept simple.</p>
    <div class="gz-divider"></div>
    <div class="how-grid">
        <div class="how-card">
            <span class="how-icon">📱</span>
            <div class="how-title">Sensor Data</div>
            <p class="how-desc">Your phone's accelerometer & gyroscope capture how your body moves - 245 signals per reading.</p>
        </div>
        <div class="how-card">
            <span class="how-icon">🧠</span>
            <div class="how-title">AI Classification</div>
            <p class="how-desc">A tuned Gradient Boosting model - trained on thousands of real readings - classifies every moment.</p>
        </div>
        <div class="how-card">
            <span class="how-icon">⚡</span>
            <div class="how-title">Your Bar</div>
            <p class="how-desc">The result isn't a number or a chart. It's one honest visual: your energy bar, filling or draining.</p>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

# ── ⑤ UNDER THE HOOD ─────────────────────────────────────────────────────────
st.markdown("""
<div class="gz-section">
    <div class="gz-section-title">Under the Hood</div>
    <p class="gz-section-sub">For the curious and the technical.</p>
    <div class="gz-divider"></div>
</div>
""", unsafe_allow_html=True)

with st.expander("🔬  See the model details"):
    c1, c2 = st.columns([1, 1], gap="medium")
    with c1:
        st.markdown("""
        <div class="stats-grid">
            <div class="stat-chip">
                <div class="stat-chip-label">Model</div>
                <div class="stat-chip-value">Gradient Boosting</div>
            </div>
            <div class="stat-chip">
                <div class="stat-chip-label">Validation Accuracy</div>
                <div class="stat-chip-value">99.46%</div>
            </div>
            <div class="stat-chip">
                <div class="stat-chip-label">Test Accuracy</div>
                <div class="stat-chip-value">96.47%</div>
            </div>
            <div class="stat-chip">
                <div class="stat-chip-label">Sensor Features</div>
                <div class="stat-chip-value">245</div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    with c2:
        st.markdown("""
        <div class="stat-chip" style="margin-bottom:1rem;">
            <div class="stat-chip-label">Hyperparameters</div>
            <div style="font-family:'DM Sans',sans-serif;font-size:0.9rem;color:#5C5048;margin-top:0.5rem;line-height:1.8;">
                n_estimators: <strong>500</strong><br>
                learning_rate: <strong>0.2</strong><br>
                max_depth: <strong>4</strong><br>
                subsample: <strong>0.8</strong><br>
                min_samples_split: <strong>5</strong>
            </div>
        </div>
        <div class="stat-chip">
            <div class="stat-chip-label">Classes</div>
            <div style="font-family:'DM Sans',sans-serif;font-size:0.9rem;color:#5C5048;margin-top:0.5rem;line-height:1.8;">
                🪑 SEDENTARY (sitting + laying)<br>
                🧍 STANDING<br>
                🏃 ACTIVE (walking variants)
            </div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("""
    <div class="trophy-banner">
        <span style="font-size:2rem;">🏆</span>
        <div>
            <div class="trophy-text">1st Place - MotionSense AI Competition</div>
            <div class="trophy-sub">Pipeline: Raw sensors → feature engineering → correlation pruning → RF importance → Gradient Boosting with GridSearchCV</div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# ── ⑥ FOOTER ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class="gz-footer">
    <div class="gz-footer-title">GenerZy ⚡</div>
    <div class="gz-footer-tagline">"Small steps. Big energy. Keep your bar alive."</div>
    <div class="gz-footer-names">
        Built with ❤ by <strong style="color:#EDE8E0;">Maryam Shanabli</strong> & <strong style="color:#EDE8E0;">Lujain Osaily</strong><br>
        <span style="font-size:0.8rem;color:#5C5048;">MotionSense AI Competition · 2025</span>
    </div>
</div>
""", unsafe_allow_html=True)